<?php
error_reporting (E_ALL ^ E_NOTICE);
$post = (!empty($_POST)) ? true : false;
if($post) {
        
     
        $to = 'mail@mail.mail'; // insert your email for contacts form sending data
		  
        $subject = stripslashes($_POST['name']) ." via Simpicity";		
        $name = stripslashes($_POST['name']);
        $email = trim($_POST['email']); 
		$website = trim($_POST['website']);		
        $message = trim($_POST['message']);
		           
        $body = "<br>$message <br><br>";
		$body.= "<br>$website <br><br>";
        $body.="---<br>Best regards,<br><strong>$name</strong>";             
        
          
                
       
        
        // Let's send the email.
                
        $headers = "from: $name <$email>\nReply-To: $email \nContent-type: text/html";
        
        $mail = mail($to, $subject, $body, $headers);        

        if($mail) {
                echo "success";
                }
}
?>
 
