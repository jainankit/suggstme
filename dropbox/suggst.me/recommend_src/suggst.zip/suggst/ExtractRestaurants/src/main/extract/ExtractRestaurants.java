package main.extract;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

/*import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.tidy.Tidy;
*/
// jsoup
import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;

/**
 * 
 * @author sharadjain
 *
 */

public class ExtractRestaurants {
	 public static void main(String argv[]) {

	  try {
		 /* Tidy tidy = new Tidy();
		  BufferedInputStream in = new BufferedInputStream(new FileInputStream("/suggest/zomato/tidy.html"));
		  BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream("/suggest/zomato/zomato_tidy.html"));
		  tidy.parseDOM(in, out);
		  in.close();
		  out.close();
		  */
		/*  if(true)
		  {
			  LocationInfo.GetLatLong("9, Sardar Patel Marg, Diplomatic Enclave, Chanakyapuri, Delhi");
			  return;
		  }
		  
		  if(true)
		  {
			  String sTimingInfo = "12:59 Am to 12Noon";
			  //FormatTime formatTime = new FormatTime();
			  int timingInfo[] = FormatTime.GetTimingInfoIn24Hrs(sTimingInfo);
			  
			  System.out.println("StartTime - " + timingInfo[0] + ":" + timingInfo[1]);
			  System.out.println("EndTime - " + timingInfo[2] + ":" + timingInfo[3]);
			  
			  return;
		  }*/
		  
		boolean bNoMore = false;
		BufferedWriter csvRestInfo = new BufferedWriter(new FileWriter("/suggest/zomato/csv/ncr/restaurant_info.csv", true));
		BufferedWriter csvRestCuisine = new BufferedWriter(new FileWriter("/suggest/zomato/csv/ncr/restaurant_cuisine.csv", true));
		BufferedWriter csvRestTel = new BufferedWriter(new FileWriter("/suggest/zomato/csv/ncr/restaurant_tel.csv", true));
		BufferedWriter csvRestRating = new BufferedWriter(new FileWriter("/suggest/zomato/csv/ncr/restaurant_rating.csv", true));
		BufferedWriter csvRestOptions = new BufferedWriter(new FileWriter("/suggest/zomato/csv/ncr/restaurant_options.csv", true));
		BufferedWriter csvRestTiming = new BufferedWriter(new FileWriter("/suggest/zomato/csv/ncr/restaurant_timing.csv", true));
		
		String city = "ncr";
		int count = 4001;
		int num = 200;
		while((bNoMore != true)){
			++num;
		    
			if(278 == num) {
				bNoMore = true;
			}
			String zomatoURL = "http://www.zomato.com/" + city + "/restaurants?page=" + num;
			String zomatoFile = "/suggest/zomato/" + city + "/zomato_" + num + ".html";
/*			URL url = new URL(zomatoURL);
			try {
				BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
				
				
				BufferedWriter writer = new BufferedWriter(new FileWriter(zomatoFile));
			
			String line;
			while((line=reader.readLine())!=null){
				//System.out.println(line);
				writer.write(line);
				writer.newLine();
			}
			reader.close();
			writer.close();
			//x++;
			}
			catch(IOException m){
				System.out.println("No more links");
				m.printStackTrace();
				bNoMore = true;
				break;
			}
	*/
			  File file = new File(zomatoFile);
			  Document doc = Jsoup.parse(file, "utf-8");
			  Elements resultElements = doc.select("li.search-result");
			  
		  
			  for (Element resultElement : resultElements) {
				 
				 String restName = null, restID = null, cuisine = null, address = null, rating = null, cost = null, time = null, votes = null;
				 String locInfo[] = null;
				 // restaurant name and cuisine
				 Elements aelements = resultElement.select("div.search-name");
				 for (Element aelement : aelements) {
					 
					 // restaurant name
					 Element nameElement = aelement.select("h3 > a").first();
					 restName = nameElement.text();
					 System.out.println(count++ + ": Restaurant Name " + restName);
					 
					 // restaurant - link
					 String restLink = nameElement.attr("href");
					 //System.out.println("Rest Link" + restLink);
					 
					 
					 // restaurant - id
					 String restaurantText = nameElement.attr("href");
					 int lasthyphen = restaurantText.lastIndexOf('-');
					 restID = restaurantText.substring(lasthyphen + 1);
					 //System.out.println("Restaurant id " + restID);
	
					 // parse individual restaurant data and populate phone data
					 locInfo = ParseRestaurant.PopulateData(restLink, restID, csvRestTel, city);

					 // cuisine and address
					 Elements pElements = aelement.select("p[title]");
					 for (Element pElement : pElements) {
	
						 if(pElement.hasClass("tags")) {
							 cuisine = pElement.attr("title");
							 
							 
							 //System.out.println("Cuisine Name " + cuisine);
						 }
						 else {
							 address = pElement.attr("title");
							 //System.out.println("Address " + address);
						 }
					 }
					 
					 
					 // rating
					 Element ratingElement = aelement.select("span.ratingtext").first();
					 String ratingText = ratingElement.text();
					 int start = ratingText.indexOf(':') + 2;
					 int end = ratingText.indexOf('/');
					 
					 rating = ratingText.substring(start, end);
					 //System.out.println("Rating " + rating);
					 
					 // votes
					 start = ratingText.indexOf('(') + 1;
					 end = ratingText.indexOf("votes") - 1;
					 votes = ratingText.substring(start, end);
					 //System.out.println("votes " + votes);
				 } // search-name
				 
				 Element costElement = resultElement.select("div.search-details").first();
				 
				 // cost
				 cost = costElement.ownText();
				 cost = cost.substring(4);
				 //System.out.println("Cost " + cost);
				 
				 // time
				 Element timeElement = costElement.select("div[title]").first();
				 time = timeElement.attr("title");
				 FormatTime.PopulateTiming(time, csvRestTiming, restID);
				 //System.out.println("Time " + time + "\n");
				 
				 boolean bCard = false, bBar = false, bVeg = false, bDel = false, bDine = false;  
				 Elements miscElements = resultElement.select("div.search-result-icons div");
				 for (Element miscElement : miscElements) {
					 
					 String miscClass = miscElement.attr("class");
					 
					 if(0 == miscClass.compareToIgnoreCase("small_res_icons small_icon_ccard tooltip")) {
						 bCard = true;
					 }
					 else if(0 == miscClass.compareToIgnoreCase("small_res_icons small_icon_bar tooltip")) {
						 bBar = true;
					 }
					 else if(0 == miscClass.compareToIgnoreCase("small_res_icons small_icon_veg tooltip")) {
						 bVeg = true;
					 }
					 else if(0 == miscClass.compareToIgnoreCase("small_res_icons small_icon_delivery tooltip")) {
						 bDel = true;
					 }
					 else if(0 == miscClass.compareToIgnoreCase("small_res_icons small_icon_dinein tooltip")) {
						 bDine = true;
					 }
				 }
				 
				 // writing different cuisine for each restaurant
				 String[] cuisineType = cuisine.split(",");
				 int cuisineSize = cuisineType.length;
  				 for(int i=0;i<cuisineSize;i++) {
  					 String csvCusine = restID + "," + cuisineType[i].trim();
  					 csvRestCuisine.write(csvCusine);
  					 csvRestCuisine.newLine();
  				 }
				 
				 String csvRating = restID + "," + rating + "," + votes + "," + cost;
				 csvRestRating.write(csvRating);
				 csvRestRating.newLine();
				 
				 String csvOptions = restID + "," + bCard + "," + bBar + "," + bVeg + "," + bDel + "," + bDine;
				 csvRestOptions.write(csvOptions);
				 csvRestOptions.newLine();
				 
				 // write rest Info string
				 String csvInfo = restID + ",\"" + restName + "\",\"" + address + "\"," + locInfo[0] + "," + locInfo[1];
				 csvRestInfo.write(csvInfo);
				 csvRestInfo.newLine();

				 
			  }
		}
		csvRestInfo.close();
		csvRestCuisine.close();
		csvRestTel.close();
		csvRestOptions.close();
		csvRestRating.close();
		csvRestTiming.close();
		  
	  } catch (Exception e) {
	    e.printStackTrace();
	  }

	 }
}
