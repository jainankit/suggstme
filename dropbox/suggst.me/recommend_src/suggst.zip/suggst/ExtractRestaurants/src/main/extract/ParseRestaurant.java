package main.extract;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * 
 * @author sharadjain
 *
 */
public class ParseRestaurant {
		
	public static String[] PopulateData(String sLink, String restID, BufferedWriter csvRestTel, String city) {
		
		try {
			String restFile = "/suggest/zomato/" + city + "/data/restaurant_" + restID + ".html";
			URL url = new URL(sLink);
			try {
				BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
				
				
				BufferedWriter writer = new BufferedWriter(new FileWriter(restFile));
			
				String line;
				while((line=reader.readLine())!=null){
					//System.out.println(line);
					writer.write(line);
					writer.newLine();
				}
				reader.close();
				writer.close();
			//x++;
			}
			catch(IOException m){
				System.out.println("No more links");
				m.printStackTrace();
				return null;
			}

			File file = new File(restFile);
			Document doc = Jsoup.parse(file, "utf-8");
			Elements telElements = doc.select("span#phoneNoString strong.tel span");
			boolean bTelFound = false;
			for(Element telElement : telElements) {
				String telNo = telElement.ownText();
				String csvTel = restID + "," + telNo;
				csvRestTel.write(csvTel);
				csvRestTel.newLine();
				bTelFound = true;
			}
			
			if(bTelFound != true) {
				String csvTel = restID + "," + "";
				csvRestTel.write(csvTel);
				csvRestTel.newLine();
			}
			
			// get the coordinates
			Elements tabDivElements = doc.select("div#tab-container > div");
			for(Element tabDivElement : tabDivElements) {
				String sClass = tabDivElement.attr("class");
				if(0 == sClass.compareToIgnoreCase("grid_2 column omega")) {
					Element mapElement = tabDivElement.select("section > a > img.img-border").first();
					if(mapElement == null) {
						String [] locInfo = {"", ""};
						return locInfo;
					}
						
					String mapText = mapElement.attr("src");
					
					// need to parse mapText
					int nstart = mapText.indexOf("center=") + 7;
					int end = mapText.indexOf('&', nstart);
					String latlong = mapText.substring(nstart, end);
					
					String[] locInfo = latlong.split(",");
					return locInfo;

					/*
					String slat = locInfo[0].trim();
					String slong = locInfo[1].trim();
					System.out.println("Lat: " + slat);
					System.out.println("Long: " + slong);
					*/
					
				}
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		return null;
	}

}
