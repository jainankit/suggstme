package main.extract;

import java.io.BufferedWriter;

/**
 * 
 * @author sharadjain
 *
 */
public class FormatTime {
	
	public static int[] Get24HrMin(String s12HrTime) {
		int hr = 0;
		int min = 0;
		
		if(-1 != s12HrTime.indexOf("PM")) {
			String temp = s12HrTime.substring(0, s12HrTime.indexOf("PM")).trim();
			int colonIndex = temp.indexOf(':');
			if(-1 != colonIndex) {
				hr = Integer.parseInt(temp.substring(0, colonIndex).trim());
				min = Integer.parseInt(temp.substring(colonIndex + 1).trim());
				if (hr < 12) {
					hr += 12;
				}
			}
			else {
				hr = 12 + Integer.parseInt(temp);
			}
		}
		else if(-1 != s12HrTime.indexOf("AM")) {
			String temp = s12HrTime.substring(0, s12HrTime.indexOf("AM")).trim();
			int colonIndex = temp.indexOf(':');
			if(-1 != colonIndex) {
				hr = Integer.parseInt(temp.substring(0, colonIndex).trim());
				min = Integer.parseInt(temp.substring(colonIndex + 1).trim());
				if (hr >= 12) {
					hr -= 12;
				}
			}
			else {
				hr = Integer.parseInt(temp);
			}
		}
		else if(-1 != s12HrTime.indexOf("NOON")) {
			hr = 12;
		}
		else if(-1 != s12HrTime.indexOf("MIDNIGHT")) {
			hr = 0;
		}
		
		int returnValue[] = {hr, min};
		return returnValue;
	}

	public static void PopulateTiming(String sTimingInfo, BufferedWriter bw, String restID) {
		
		try {
			String[] timingInfo = sTimingInfo.split("[,()]");
			int infoSize = timingInfo.length;
			int i=0;
			for(;i<infoSize;i++) {
				
				String singleTimeInfo = timingInfo[i].trim();
				
				if(0 == singleTimeInfo.compareToIgnoreCase("24 Hours")) {
				
					String csvLine = restID + "," + 0 + "," + 0 + "," + 0 + "," + 0;
					bw.write(csvLine);
					bw.newLine();
					continue;
				}
				
				if(-1 != singleTimeInfo.indexOf("to")) {
					String[] timeParts = timingInfo[i].split("to");
					if(timeParts.length == 2) {
						String startTime = timeParts[0].trim().toUpperCase();
						String endTime = timeParts[1].trim().toUpperCase();
						
						int start[] = Get24HrMin(startTime);
						int end[] = Get24HrMin(endTime);
						String csvLine = restID + "," + start[0] + "," + start[1] + "," + end[0] + "," + end[1];
						bw.write(csvLine);
						bw.newLine();
					}
					continue;
				}
				
				// Miscelaanous info
				
			}
		}
		catch (Exception e) {
		    e.printStackTrace();
		  }
					
	}
}
