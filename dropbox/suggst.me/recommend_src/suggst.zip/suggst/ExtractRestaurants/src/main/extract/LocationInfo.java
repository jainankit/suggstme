package main.extract;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * 
 * @author sharadjain
 *
 */
public class LocationInfo {

	public static void GetLatLong(String address) {

		//address.replace(' ', '+');
		String addressURL = "http://maps.googleapis.com/maps/api/geocode/xml?address=" + address.replace(' ', '+') + "&sensor=false";
		try {
			System.out.println("URL : " + addressURL);
			URL url = new URL(addressURL);
			InputStream stream = url.openStream();
			
	    	BufferedReader br = new BufferedReader(new InputStreamReader(stream));
	 
	    	StringBuilder sb = new StringBuilder();
	 
	    	String line;
	    	while ((line = br.readLine()) != null) {
	    		sb.append(line);
	    	}
	    	
	    	String html = sb.toString();
	    	
			Document doc = Jsoup.parse(html);//   . parse(stream, "utf-8", null);
			
			String status = doc.select("GeocodeResponse > status").first().text();
			if(0 != status.compareToIgnoreCase("OK"))
			{
				System.out.println("Google API didnt return OK");
				return;
			}
			Element locElement = doc.select("geometry > location").first();
		    
			String lat = locElement.select("lat").first().text();
		    String lng = locElement.select("lng").first().text();
		    System.out.println("Latitude : " + lat);
		    System.out.println("Longitude : " + lng);
		    
		    Element locTypeElement = doc.select("geometry > location_type").first();
		    String locType = locTypeElement.text();
		    System.out.println("LocType : " + locType);
		    
		}
		catch(Exception m){
			System.out.println("No more links");
			m.printStackTrace();
		}
		
		return;
	}
}
