package com.se.datamodel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.IOUtils;
import org.apache.mahout.cf.taste.impl.model.jdbc.AbstractJDBCDataModel;
import org.apache.mahout.cf.taste.model.DataModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * JDBC-based {@link DataModel} implementations
 * 
 * @author ankit
 * 
 */
public class JDBCDataModelImpl extends AbstractJDBCDataModel {

	private static final Logger log = LoggerFactory
			.getLogger(AbstractJDBCDataModel.class);

	private static final String preferenceTable = "ratings";
	private static final String userIDColumn = "user_id";
	private static final String itemIDColumn = "item_id";
	private static final String preferenceColumn = "rating";
	private static final String getPreferenceSQL = "SELECT " + preferenceColumn + " FROM " + preferenceTable + " WHERE " + userIDColumn + "=? AND " + itemIDColumn + "=?";
    private static final String getUserSQL = "SELECT " + userIDColumn + ", " + itemIDColumn + ", " + preferenceColumn + " FROM " + preferenceTable + " WHERE " + userIDColumn + "=? ORDER BY " + itemIDColumn;
    private static final String getAllUsersSQL = "SELECT " + userIDColumn + ", " + itemIDColumn + ", " + preferenceColumn + " FROM " + preferenceTable + " ORDER BY " + userIDColumn + ", " + itemIDColumn;
    private static final String getNumItemsSQL = "SELECT COUNT(DISTINCT " + itemIDColumn + ") FROM " + preferenceTable;
    private static final String getNumUsersSQL = "SELECT COUNT(DISTINCT " + userIDColumn + ") FROM " + preferenceTable;
    private static final String setPreferenceSQL = "INSERT INTO " + preferenceTable + '(' + userIDColumn + ',' + itemIDColumn + ',' + preferenceColumn + ") VALUES (?,?,?) ON DUPLICATE KEY UPDATE " + preferenceColumn + "=?";
    private static final String removePreferenceSQL = "DELETE FROM " + preferenceTable + " WHERE " + userIDColumn + "=? AND " + itemIDColumn + "=?";
    private static final String getUsersSQL = "SELECT DISTINCT " + userIDColumn + " FROM " + preferenceTable + " ORDER BY " + userIDColumn;
    private static final String getItemsSQL = "SELECT DISTINCT " + itemIDColumn + " FROM " + preferenceTable + " ORDER BY " + itemIDColumn;
    private static final String getPrefsForItemSQL = "SELECT " + userIDColumn + ", " + itemIDColumn + ", " + preferenceColumn + " FROM " + preferenceTable + " WHERE " + itemIDColumn + "=? ORDER BY " + userIDColumn;
    private static final String getNumPreferenceForItemSQL = "SELECT COUNT(1) FROM " + preferenceTable + " WHERE " + itemIDColumn + "=?";
    private static final String getNumPreferenceForItemsSQL = "SELECT COUNT(1) FROM " + preferenceTable + " tp1 JOIN " + preferenceTable + " tp2 " + "USING (" + userIDColumn + ") WHERE tp1." + itemIDColumn + "=? and tp2." + itemIDColumn + "=?";

	private DataSource dataSource; 

	public JDBCDataModelImpl(DataSource dataSource) {
		super(dataSource, preferenceTable, userIDColumn, itemIDColumn,
				preferenceColumn, getPreferenceSQL, getUserSQL, getAllUsersSQL,
				getNumItemsSQL, getNumUsersSQL, setPreferenceSQL,
				removePreferenceSQL, getUsersSQL, getItemsSQL,
				getPrefsForItemSQL, getNumPreferenceForItemSQL,
				getNumPreferenceForItemsSQL);
		this.dataSource = dataSource;
	}
	
	/**
	 * added this as the implementation in AbstractJDBCDataModel requires to set 3 values for some reason
	 */
	@Override
	public void setPreference(long userID, long itemID, float value)
			throws TasteException {
		if (Float.isNaN(value)) {
			throw new IllegalArgumentException("Invalid value: " + value);
		}

		log.debug("Setting preference for user {}, item {}", userID, itemID);

		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(setPreferenceSQL);
			stmt.setLong(1, userID);
			stmt.setLong(2, itemID);
			stmt.setDouble(3, value);

			log.debug("Executing SQL update: {}", setPreferenceSQL);
			stmt.executeUpdate();

		} catch (SQLException sqle) {
			log.warn("Exception while setting preference", sqle);
			throw new TasteException(sqle);
		} finally {
			IOUtils.quietClose(null, stmt, conn);
		}
	}
}
