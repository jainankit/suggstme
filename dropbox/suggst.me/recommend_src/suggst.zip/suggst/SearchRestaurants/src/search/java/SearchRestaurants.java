package search.java;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.Version;

import com.se.index.ResIndex;
import com.se.search.ResSearch;
/**
 * 
 * @author sharadjain
 *
 */

public class SearchRestaurants {
	
	public static void main(String[] args) {
		
		String sIndex = "/suggest/zomato/index";
		// Make an index
		ResIndex resIndex = new ResIndex("smreco", "root", "");
		resIndex.SetTables("sm_res_info");
		boolean bSucceed = resIndex.MakeIndex(sIndex);
		if(!bSucceed)
		{
			// need to add failure logging
			return;
		}
		
		String sQuery = "tikk";
		ResSearch resSearch = new ResSearch(sIndex);
		resSearch.SearchRestaurants(sQuery);
		
	}
}
