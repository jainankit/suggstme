package com.se.index;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

/**
 * 
 * @author sharadjain
 *
 */

public class ResIndex {
	
	private final String DataBaseName;
	private final String UserName;
	private final String Password;
	private String ResInfoTableName;
	
	public ResIndex(String DataBaseName, String UserName, String Password) {
		this.DataBaseName = DataBaseName;
		this.UserName = UserName;
		this.Password = Password;
	}
	
	public void SetTables(String sTableName) {
		this.ResInfoTableName = sTableName;
	}

	public boolean MakeIndex(String sIndexFile) {
	
		try {
			
			// We will build indexes containing text from restaurant names and places and we will associate 
			// some identifier to indicate whether it is a name of a restaurant or a place. This way if the user types 
			// some places, we can show a list of restaurants nearby to that area
		    
			// using an empty set since we dont want any of the words to be stop words. Every word has importance
			Set set = new HashSet();
			
			// we might want to use adifferent analyzer 
			// since we will be searching only restaurants and locations, we dont require stemmer
			StandardAnalyzer analyzer = new StandardAnalyzer(Version.LUCENE_35, set);
			
			// index and search
			// needs to decide which index to use, should look into FSDirectory, so that index can be searched
			FSDirectory index = FSDirectory.open(new File(sIndexFile));
			
			IndexWriterConfig config = new IndexWriterConfig(Version.LUCENE_35, analyzer);
			config.setOpenMode(IndexWriterConfig.OpenMode.CREATE);
			IndexWriter w = new IndexWriter(index, config);
			
		    Connection conn = null;

		    // try to get the recommendation for all the users
		    try
		    {
		        String url = "jdbc:mysql://localhost/" + DataBaseName;
		        Class.forName ("com.mysql.jdbc.Driver").newInstance ();
		        conn = DriverManager.getConnection (url, UserName, Password);
		        System.out.println ("Database connection established");
		        
	    		Statement stmt = conn.createStatement();
	    		String query = "SELECT name, resid, address FROM " + ResInfoTableName;
	    		ResultSet rsUsers = stmt.executeQuery(query);
	
		        while (rsUsers.next()) {
		        	String ResName = rsUsers.getString(1);
		        	
		        	long ResId = rsUsers.getLong(2);
		        	System.out.println("Rest Id : " + ResId + " : " + ResName);
		        	
		        	String sResId = String.format("%d", ResId);
		        	
		        	String Address = rsUsers.getString(3);
		        	
		        	addDoc(w, ResName, sResId, Address);
		        }
		    }
		    catch (Exception e) {
				System.out.println("Failed to get data " + e.getMessage());
				return false;
			}
			
			/*
			// to index using a file
			
			FileInputStream fstream = new FileInputStream("/suggest/zomato/csv/ncr/restaurant_info.csv");
  		    // Get the object of DataInputStream
		    DataInputStream in = new DataInputStream(fstream);
		    BufferedReader br = new BufferedReader(new InputStreamReader(in));
		    String strLine;
		    //Read File Line By Line
		    while ((strLine = br.readLine()) != null)   {
			    // Print the content on the console
			    String infoParts[] = strLine.split(",");
			    //System.out.println(infoParts.length);
			    if(infoParts.length >= 2 ) {
			    	//System.out.println(infoParts[1] + "\t" + infoParts[0]);
		    		addDoc(w, infoParts[1], infoParts[0]);
			    }
		    
		    }
		    //Close the input stream
		    in.close();
			*/
			w.close();
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
		
		return true;
	}
	
	private static void addDoc(IndexWriter w, String value, String id, String address) throws IOException {
	    Document doc = new Document();
	    doc.add(new Field("title", value, Field.Store.YES, Field.Index.ANALYZED));

	    doc.add(new Field("add", address, Field.Store.YES, Field.Index.ANALYZED));

	    // id should not be searchable, so it is not added to the index but just stored
	    doc.add(new Field("id", id, Field.Store.YES, Field.Index.NO));
	    w.addDocument(doc);
	}
}