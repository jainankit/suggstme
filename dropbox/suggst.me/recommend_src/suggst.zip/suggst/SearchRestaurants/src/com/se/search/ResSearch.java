package com.se.search;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

/**
 * 
 * @author sharadjain
 *
 */
public class ResSearch {
	
	String sIndex;
	
	public ResSearch(String sIndexPath) {
		sIndex = sIndexPath;
	}
	
	public boolean SearchRestaurants(String sQuery) {
		
	    try {
	    	
			if(sQuery.isEmpty()) {
				return false;
			}
			
			sQuery = String.format("%s%c", sQuery, '*');
			
			// using an empty set since we dont want any of the words to be stop words. Every word has importance
			Set set = new HashSet();
			
			// we might want to use adifferent analyzer 
			// since we will be searching only restaurants and locations, we dont require stemmer
			StandardAnalyzer analyzer = new StandardAnalyzer(Version.LUCENE_35, set);
			
			// index and search
			// needs to decide which index to use, should look into FSDirectory, so that index can be searched
			FSDirectory index = FSDirectory.open(new File(sIndex));
			
		    // the "title" arg specifies the default field to use
		    // when no field is explicitly specified in the query.
		    Query q = new QueryParser(Version.LUCENE_35, "title", analyzer).parse(sQuery);
	
		    // 3. search
		    int hitsPerPage = 10;
		    IndexReader reader = IndexReader.open(index);
		    IndexSearcher searcher = new IndexSearcher(reader);
		    TopScoreDocCollector collector = TopScoreDocCollector.create(hitsPerPage, true);
		    searcher.search(q, collector);
		    ScoreDoc[] hits = collector.topDocs().scoreDocs;
		    
			System.out.println("Search results");

		    // 4. display results
		    System.out.println("Found " + hits.length + " hits.");
		    for(int i=0;i<hits.length;++i) {
		      int docId = hits[i].doc;
		      Document d = searcher.doc(docId);
		      System.out.println((i + 1) + ". " + d.get("title") + "\t" + d.get("id") + "\t" + 
		    		  d.get("add") + "\t" + hits[i].score);
		    }
	
		    // searcher can only be closed when there
		    // is no need to access the documents any more. 
		    searcher.close();
			
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}

		return true;
	}

}
