package com.se.recommendation;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.model.jdbc.ConnectionPoolDataSource;
import org.apache.mahout.cf.taste.impl.neighborhood.NearestNUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.CachingRecommender;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.AveragingPreferenceInferrer;
import org.apache.mahout.cf.taste.impl.similarity.LogLikelihoodSimilarity;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;

import com.mysql.jdbc.jdbc2.optional.MysqlConnectionPoolDataSource;
import com.se.datamodel.JDBCDataModelImpl;

import java.sql.*;


public class RecommendationImpl {

	private final String DataBaseName;
	private final String RatingTableName;
	private final String UserName;
	private final String Password;
	private String RecomsTableName;
	private final String UserTableName;
	
	public RecommendationImpl(String DataBaseName, String RatingTableName, String UserTableName,
			String UserName, String Password) {
		this.DataBaseName = DataBaseName;
		this.RatingTableName = RatingTableName;
		this.UserName = UserName;
		this.Password = Password;
		this.UserTableName = UserTableName;
	}
	
	public void GenerateRecommendation(String RecomsTableName, int nRecoms) {
	
		try
		{
			this.RecomsTableName = RecomsTableName;

			String docIdsTitle = "/Users/sharadjain/gitsource/SuggestionEngine/src/main/resources/docIdsTitles.xml";
		    String recsFile = "/suggest/recommendations.txt";
		    
		    MysqlConnectionPoolDataSource dataSource = new MysqlConnectionPoolDataSource();
			dataSource.setDatabaseName(DataBaseName);
			dataSource.setUser(UserName);
			dataSource.setPassword(Password);
			dataSource.setCachePreparedStatements(true);
			dataSource.setCachePrepStmts(true);
			dataSource.setCacheResultSetMetadata(true);
			dataSource.setAlwaysSendSetIsolation(false);
			dataSource.setElideSetAutoCommits(true);
		    
			// create the SQL data model
			DataModel dataModel = new JDBCDataModelImpl(new ConnectionPoolDataSource(dataSource));
		    
		    // create file data model
			//DataModel dataModel = new FileDataModel(new File(recsFile));
		
			UserSimilarity userSimilarity = new PearsonCorrelationSimilarity(dataModel);
			userSimilarity.setPreferenceInferrer(new AveragingPreferenceInferrer(dataModel));
		  
		    // create a UserNeighborhood algorithm. Here we use nearest-10:
		    UserNeighborhood neighborhood = new NearestNUserNeighborhood(10, userSimilarity, dataModel);
		  
			// create GenericRecommender
			Recommender recommender = new GenericUserBasedRecommender(dataModel, neighborhood, userSimilarity);
		    
		    // add a caching recommender
			Recommender cachingRecommender = new CachingRecommender(recommender);
		    
		    Connection conn = null;

		    // try to get the recommendation for all the users
		    try
		    {
		        String url = "jdbc:mysql://localhost/" + DataBaseName;
		        Class.forName ("com.mysql.jdbc.Driver").newInstance ();
		        conn = DriverManager.getConnection (url, UserName, Password);
		        System.out.println ("Database connection established");
		        
	    		Statement stmt = conn.createStatement();
	    		String query = "SELECT user_id FROM " + UserTableName;
	    		ResultSet rsUsers = stmt.executeQuery(query);
	
		        while (rsUsers.next()) {
		        	long UserID = rsUsers.getLong(1);
		        	System.out.println("UserID : " + UserID);

		        	List<RecommendedItem> recommendations = cachingRecommender.recommend(UserID, nRecoms);
				    for (RecommendedItem recommendedItem : recommendations) {
				    	System.out.println(recommendedItem);
				    	Statement stmtRecoms = conn.createStatement();
			    		String queryRecoms = "INSERT INTO " +  RecomsTableName + " VALUES (\"" + UserID + "\",\"" + 
			    				recommendedItem.getItemID() + "\",\"" + recommendedItem.getValue() + 
			    				"\") ON DUPLICATE KEY UPDATE rating = " + recommendedItem.getValue() + ";";
				    	System.out.println(queryRecoms);
				    	stmtRecoms.executeUpdate(queryRecoms);
				    }// end of for
		        } //end while
		    }
		    catch (Exception e)
		    {
		        System.err.println ("Cannot inserting values into database : " + e.getMessage());
		    }
		}
		catch (Exception e)
		{
			System.err.println("Error creating recommendations : " +  e.getMessage());
		}
	}
}
